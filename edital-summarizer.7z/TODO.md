Preciso adicionar um agente que irá analisar se o documento é referente a um determinado tema.

Por exemplo:

O tema procura é RPA (Robot Process Automation) que é a automação de processos robotizados. Caso o documento do edital não seja referente ao procurado. Ele nem realiza a geração dos resumos e a gente corta o processo antes msm de gastar tokens na api do provedor.

Ai vai dar um erro de negocio e gerar um rel.xlsx contendo esse erro de negocio informando que o documento não se trata do tema procurado


----
1. Dado um target = (RPA - Robot Process Automation) eu preciso que a LLM me diga se o documento é referente ao target ou não.
2. Colocar um threshold minimo para dispositivos (celular, tablet e notebooks). Se o edital não for maior ou igual ao threshold descartar o documento e a analise.

Se o target não der match, nao fazer analise.
Se o threshold minimo nao der match nao fazer analise.


3. Iremos adicionar mais um input ao process_edital que será o target. As vezes chegam documentos que é referente a RPA por exemplo, mas o documento não é sobre RPA. Se o documento.
4. O output não será mais um xlsx. Será um json me dizendo se o target é True (deu match) or False. Se o target der True, deve então passar adiante para gerar os resumos, se for false então deve deixar o campo resumo como uma string vazia. (Iremos fazer apenas um resumo. O executivo)
5. Se o target for referente a dispositivos como por exemplo (Tablet, celular ou notebook) haverá um parametro de entrada que por default é 500 onde o edital deve ser sobre no minimo esse threshold. Se o edital nao bater o threshold atribuir o target como False. e nao gerar resumo (deixar em branco "")

process_edital.bat samples/edital-001 "Aquisição de Aeronave" 500 resultado2.json --force-match -v




---

PARA DISPOSITIVOS DE VENDA.

QUANDO O TARGET FOR VERDADEIRO, EU QUERO QUE ME RETORNE NOS METADATA A QUANTIDADE DE DISPOSITIVOS PROPOSTOS NO EDITAL. Chame essa key no metadata de volume_dispositivos: string
